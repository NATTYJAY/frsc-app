Replace the following files in their respective folders

AdminDriverController.php => In App/Http/Controller

application.js => public/assets/js/

driverEditModal.blade.php => resources/views/includes/

web.php => In the route folder